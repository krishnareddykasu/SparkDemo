package com.tech.assignment

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{row_number,sum,min,max,size,when,col,lit}
import org.apache.spark.sql.SaveMode


object SingnalCount {
  def main(args: Array[String]):Unit = {
    
    if (args.length >2 || args.length == 0 )
      throw new RuntimeException("Spark App was submitted with incomplete parameters ! Expected only the file name as input and output hdfs path to store ")
    
      val sparkSession = SparkSession.builder().enableHiveSupport().getOrCreate()
      sparkSession.sqlContext.setConf("spark.sql.parquet.compression.codec", "snappy")
      import sparkSession.implicits._
      var inputFileName = args(0)
      var target_path = args(1)
      var signals_Data = sparkSession.read.parquet(inputFileName)
    
    val window_func = Window.partitionBy($"entity_id").orderBy($"month_id".desc)
    val unique_entity = Window.partitionBy($"entity_id").orderBy($"total_signals".desc)
    
    var singal_data_transform = signals_Data.withColumn("list_of_items", org.apache.spark.sql.functions.collect_list($"item_id").over(window_func))
    singal_data_transform = singal_data_transform.withColumn("size_of_mnth", org.apache.spark.sql.functions.collect_set($"month_id").over(window_func))
    var total_signals = singal_data_transform.withColumn("total_signals", sum($"signal_count").over(window_func))
    total_signals = total_signals.withColumn("newest_item_id", when(size($"size_of_mnth") === 1,org.apache.spark.sql.functions.reverse($"list_of_items")(0))
                                                             .when(size($"size_of_mnth") > 1,$"list_of_items"(0)).otherwise($"list_of_items"(0)))
                                                             
    total_signals = total_signals.withColumn("oldest_item_id",when(size($"size_of_mnth") === 1,org.apache.spark.sql.functions.reverse($"list_of_items")(0))
                                                             .when(size($"size_of_mnth") > 1,org.apache.spark.sql.functions.reverse($"list_of_items")(0)).otherwise($"list_of_items"(0)))
    
    var write_df = total_signals.withColumn("rno", row_number().over(unique_entity))
    val final_output = write_df.where($"rno" === 1).select($"entity_id",$"oldest_item_id",$"newest_item_id",$"total_signals")
    final_output.printSchema()
    final_output.show(1000,false)
    final_output.repartition(1).write.mode(SaveMode.Overwrite).format("parquet").save(target_path)
    
  }
  
}