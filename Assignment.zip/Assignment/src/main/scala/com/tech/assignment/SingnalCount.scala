package com.tech.assignment

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{row_number,sum,min,max}
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.functions.col

object SingnalCount {
  def main(args: Array[String]):Unit = {
    
    if (args.length >2 || args.length == 0 )
      throw new RuntimeException("Spark App was submitted with incomplete parameters ! Expected only the file name as input and output hdfs path to store ")
    
      val sparkSession = SparkSession.builder().enableHiveSupport().getOrCreate()
      sparkSession.sqlContext.setConf("spark.sql.parquet.compression.codec", "snappy")
      import sparkSession.implicits._
      var inputFileName = args(0)
      var target_path = args(1)
      var rawdata = sparkSession.read.parquet(inputFileName)
    
    val window_func = Window.partitionBy($"entity_id").orderBy($"month_id".desc)
    var raw_with_rno = rawdata.withColumn("list_of_items", org.apache.spark.sql.functions.collect_set($"item_id").over(window_func))                            
    raw_with_rno.printSchema()
    var write_df = raw_with_rno.groupBy($"entity_id").agg(min($"list_of_items") as "oldest_item_id"
        ,max($"list_of_items") as "newest_month_id"
        ,sum($"signal_count") as "total_signals").
    select($"entity_id",$"oldest_item_id",$"newest_month_id",$"total_signals")
    write_df.repartition(1).write.mode(SaveMode.Overwrite).format("parquet").save(target_path)
    
  }
  
}